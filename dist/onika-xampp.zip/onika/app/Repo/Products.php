<?php
declare(strict_types=1);

namespace Onika\Repo;

use Onika\Db;
use Onika\I18n;
use Onika\Media;
use Onika\Text;

final class Products
{
    public const MAX_STOCK = 99999;

    public static function hydrate(array $r): array
    {
        // Rows from the trash made before stock_qty existed only have the in_stock flag.
        $stock = max(0, (int) ($r['stock_qty'] ?? ((int) ($r['in_stock'] ?? 1) === 1 ? 1 : 0)));
        return [
            'id' => (string) $r['id'],
            'name' => (string) $r['name'],
            'slug' => (string) $r['slug'],
            'price' => (float) $r['price'],
            'oldPrice' => $r['old_price'] !== null ? (float) $r['old_price'] : null,
            'category' => (string) ($r['category'] ?? ''),
            'brand' => $r['brand'] !== null && $r['brand'] !== '' ? (string) $r['brand'] : null,
            'description' => (string) ($r['description'] ?? ''),
            'images' => array_values(array_filter((array) Text::jsonDecode($r['images'] ?? '[]', []), 'is_string')),
            'stock' => $stock,
            'inStock' => $stock > 0,
            'featured' => (int) $r['featured'] === 1,
            'active' => (int) $r['active'] === 1,
            'sizes' => array_values(array_filter((array) Text::jsonDecode($r['sizes'] ?? '[]', []), 'is_string')),
            'tags' => array_values(array_filter((array) Text::jsonDecode($r['tags'] ?? '[]', []), 'is_string')),
            'sku' => $r['sku'] ?? null,
            'views' => (int) ($r['views'] ?? 0),
            'sales' => (int) ($r['sales'] ?? 0),
            'translations' => (array) Text::jsonDecode($r['translations'] ?? '{}', []),
            'createdAt' => $r['created_at'] ?? null,
            'updatedAt' => $r['updated_at'] ?? null,
        ];
    }

    /**
     * Product listing.
     * Filters: q, category[], brand[], min, max, in_stock, featured, sort, page, per_page,
     *          include_inactive (admin: also hidden products / hidden categories).
     * @return array{items:list<array>,total:int,page:int,pages:int,perPage:int}
     */
    public static function search(array $f = []): array
    {
        $where = [];
        $params = [];
        $admin = !empty($f['include_inactive']);
        if (!$admin) {
            $where[] = 'active = 1';
            $where[] = "COALESCE(category, '') NOT IN (SELECT name FROM categories WHERE active = 0)";
        }
        $q = mb_substr(Text::line($f['q'] ?? '', 100000), 0, 300);
        if ($q !== '') {
            // Up to 6 words, 60 characters each: SQLite rejects very long LIKE patterns ("pattern too complex").
            foreach (array_slice(preg_split('/\s+/u', Text::searchNorm(Text::lower($q))) ?: [], 0, 6) as $term) {
                if ($term === '') {
                    continue;
                }
                $where[] = "search_blob LIKE ? ESCAPE '\\'";
                $params[] = Db::like(mb_substr($term, 0, 60));
            }
        }
        $list = static fn($v): array => array_values(array_filter(
            array_map(static fn($x) => is_scalar($x) ? (string) $x : '', (array) $v),
            static fn(string $x) => $x !== ''
        ));
        $cats = $list($f['category'] ?? []);
        if ($cats) {
            $where[] = 'category IN (' . Db::in($cats) . ')';
            array_push($params, ...$cats);
        }
        $brands = $list($f['brand'] ?? []);
        if ($brands) {
            $where[] = 'brand IN (' . Db::in($brands) . ')';
            array_push($params, ...$brands);
        }
        if (isset($f['min']) && $f['min'] !== '' && is_numeric($f['min'])) {
            $where[] = 'price >= ?';
            $params[] = (float) $f['min'];
        }
        if (isset($f['max']) && $f['max'] !== '' && is_numeric($f['max'])) {
            $where[] = 'price <= ?';
            $params[] = (float) $f['max'];
        }
        if (!empty($f['in_stock'])) {
            $where[] = 'stock_qty > 0';
        }
        if (!empty($f['featured'])) {
            $where[] = 'featured = 1';
        }
        if (isset($f['status']) && is_scalar($f['status']) && $f['status'] !== '') {
            $where[] = match ((string) $f['status']) {
                'active' => 'active = 1',
                'hidden' => 'active = 0',
                'out' => 'stock_qty <= 0',
                default => '1 = 1',
            };
        }
        $sql = $where ? ' WHERE ' . implode(' AND ', $where) : '';

        $order = match (is_scalar($f['sort'] ?? null) ? (string) $f['sort'] : 'new') {
            'price-asc' => 'price ASC, id DESC',
            'price-desc' => 'price DESC, id DESC',
            // Every order ends with a unique column: equal names/views must not swap places between pages.
            'popular' => 'views DESC, created_at DESC, id DESC',
            'name' => 'name COLLATE NOCASE ASC, id ASC',
            default => 'created_at DESC, id DESC',
        };

        $total = (int) Db::val('SELECT COUNT(*) FROM products' . $sql, $params);
        $perPage = max(1, min(100, is_numeric($f['per_page'] ?? null) ? (int) $f['per_page'] : (int) cfg('per_page', 24)));
        $pages = max(1, (int) ceil($total / $perPage));
        $page = max(1, min($pages, is_numeric($f['page'] ?? null) ? (int) min(PHP_INT_MAX, (float) $f['page']) : 1));
        $rows = Db::all(
            'SELECT * FROM products' . $sql . ' ORDER BY ' . $order . ' LIMIT ? OFFSET ?',
            array_merge($params, [$perPage, ($page - 1) * $perPage])
        );
        return [
            'items' => array_map([self::class, 'hydrate'], $rows),
            'total' => $total,
            'page' => $page,
            'pages' => $pages,
            'perPage' => $perPage,
        ];
    }

    public static function find(string $idOrSlug): ?array
    {
        $r = Db::one('SELECT * FROM products WHERE id = ? OR slug = ? LIMIT 1', [$idOrSlug, $idOrSlug]);
        return $r ? self::hydrate($r) : null;
    }

    /** Storefront-visible product by slug/id (active and category not hidden). */
    public static function findVisible(string $idOrSlug): ?array
    {
        $p = self::find($idOrSlug);
        if (!$p || !$p['active']) {
            return null;
        }
        $hidden = (int) Db::val('SELECT COUNT(*) FROM categories WHERE name = ? AND active = 0', [$p['category']]);
        return $hidden ? null : $p;
    }

    /**
     * Products by ids for cart / favourites / recently viewed. Unknown or hidden ids are skipped.
     * @param list<string> $ids
     * @return list<array>
     */
    public static function byIds(array $ids): array
    {
        $ids = array_values(array_unique(array_filter(array_map('strval', $ids), fn($s) => $s !== '' && strlen($s) <= 64)));
        $ids = array_slice($ids, 0, 60);
        if (!$ids) {
            return [];
        }
        $rows = Db::all(
            'SELECT * FROM products WHERE active = 1 AND id IN (' . Db::in($ids) . ')'
            . " AND COALESCE(category, '') NOT IN (SELECT name FROM categories WHERE active = 0)",
            $ids
        );
        $by = [];
        foreach ($rows as $r) {
            $by[(string) $r['id']] = self::hydrate($r);
        }
        $out = [];
        foreach ($ids as $id) {          // keep requested order
            if (isset($by[$id])) {
                $out[] = $by[$id];
            }
        }
        return $out;
    }

    /**
     * First photo of the most popular visible product of each category (home page tiles), in one query.
     * Same order as search(['sort' => 'popular']): views DESC, created_at DESC, id DESC.
     * @param list<string> $categories
     * @return array<string,?string> category name => image path (null when that product has no photo)
     */
    public static function coverPerCategory(array $categories): array
    {
        $categories = array_values(array_unique(array_map('strval', $categories)));
        if (!$categories) {
            return [];
        }
        try {
            $rows = Db::all(
                'SELECT category, images FROM (
                    SELECT category, images, ROW_NUMBER() OVER (PARTITION BY category ORDER BY views DESC, created_at DESC, id DESC) AS rn
                    FROM products WHERE active = 1 AND category IN (' . Db::in($categories) . ')
                 ) WHERE rn = 1',
                $categories
            );
        } catch (\PDOException) {       // SQLite older than 3.25 (no window functions)
            $rows = [];
            foreach ($categories as $c) {
                $r = Db::one('SELECT category, images FROM products WHERE active = 1 AND category = ? ORDER BY views DESC, created_at DESC, id DESC LIMIT 1', [$c]);
                if ($r) {
                    $rows[] = $r;
                }
            }
        }
        $out = array_fill_keys($categories, null);
        foreach ($rows as $r) {
            $imgs = array_values(array_filter((array) Text::jsonDecode($r['images'] ?? '[]', []), 'is_string'));
            $out[(string) $r['category']] = $imgs[0] ?? null;
        }
        return $out;
    }

    public static function related(array $p, int $limit = 8): array
    {
        $rows = Db::all(
            'SELECT * FROM products WHERE active = 1 AND category = ? AND id <> ?'
            . ' ORDER BY (brand = ?) DESC, views DESC, created_at DESC LIMIT ?',
            [$p['category'], $p['id'], (string) ($p['brand'] ?? ''), $limit]
        );
        return array_map([self::class, 'hydrate'], $rows);
    }

    public static function incrementViews(string $id): void
    {
        Db::exec('UPDATE products SET views = views + 1 WHERE id = ?', [$id]);
    }

    /** Live-search suggestions for the header search box. */
    public static function suggest(string $q, int $limit = 6): array
    {
        return self::search(['q' => $q, 'per_page' => $limit, 'sort' => 'popular'])['items'];
    }

    /** @return array{ok:bool,product?:array,errors?:array<string,string>} */
    public static function save(array $in, ?string $id = null): array
    {
        $existing = $id ? self::find($id) : null;
        if ($id && !$existing) {
            return ['ok' => false, 'errors' => ['id' => 'not_found']];
        }
        $errors = [];
        $name = trim((string) ($in['name'] ?? ($existing['name'] ?? '')));
        if ($name === '') {
            $errors['name'] = 'required';
        }
        $price = isset($in['price']) ? str_replace(',', '.', (string) $in['price']) : (string) ($existing['price'] ?? '0');
        if (!is_numeric($price) || (float) $price < 0) {
            $errors['price'] = 'invalid';
        }
        // Stock = whole pieces (0 = out of stock). Empty keeps the current value (1 for a new product).
        $stockRaw = array_key_exists('stock', $in) ? trim((string) $in['stock']) : '';
        if ($stockRaw !== '' && !ctype_digit($stockRaw)) {
            $errors['stock'] = 'invalid';
        }
        if ($errors) {
            return ['ok' => false, 'errors' => $errors];
        }
        $price = round((float) $price, 2);

        $oldRaw = array_key_exists('oldPrice', $in) ? str_replace(',', '.', trim((string) $in['oldPrice'])) : (string) ($existing['oldPrice'] ?? '');
        $old = is_numeric($oldRaw) && (float) $oldRaw > $price ? round((float) $oldRaw, 2) : null;

        $category = trim((string) ($in['category'] ?? ($existing['category'] ?? '')));
        if ($category === '') {
            $category = 'Інше';
        }
        Categories::ensure($category);

        $brand = array_key_exists('brand', $in) ? trim((string) $in['brand']) : (string) ($existing['brand'] ?? '');
        if ($brand !== '') {
            Brands::ensure($brand);
        }

        $sizes = $in['sizes'] ?? ($existing['sizes'] ?? []);
        if (is_string($sizes)) {
            $sizes = preg_split('/[,\n;]+/u', $sizes) ?: [];
        }
        $sizes = array_slice(array_values(array_unique(array_filter(array_map(fn($s) => Text::truncate((string) $s, 20), (array) $sizes), 'strlen'))), 0, 30);

        $images = $in['images'] ?? ($existing['images'] ?? []);
        if (is_string($images)) {
            $images = preg_split('/[\n,]+/u', $images) ?: [];
        }
        $clean = [];
        foreach ((array) $images as $src) {
            $src = trim((string) $src);
            if ($src === '') {
                continue;
            }
            if (Media::isExternal($src)) {
                if (preg_match('#^https?://#i', $src)) {
                    $clean[] = $src;
                }
            } elseif (Media::exists($src)) {
                $clean[] = ltrim(str_replace('\\', '/', $src), '/');
            }
        }
        $clean = array_slice(array_values(array_unique($clean)), 0, 20);

        $description = Text::clean((string) ($in['description'] ?? ($existing['description'] ?? '')));

        $tr = $existing['translations'] ?? [];
        if (isset($in['translations']) && is_array($in['translations'])) {
            foreach (['ru', 'en'] as $l) {
                $n = trim((string) ($in['translations'][$l]['name'] ?? ''));
                $d = Text::clean((string) ($in['translations'][$l]['description'] ?? ''));
                if ($n === '' && $d === '') {
                    unset($tr[$l]);
                } else {
                    $tr[$l] = ['name' => $n, 'description' => $d];
                }
            }
        }

        $flag = static fn(string $k, bool $def): int => array_key_exists($k, $in) ? (Text::boolish($in[$k]) ? 1 : 0) : ($existing ? (int) $existing[$k] : (int) $def);
        $featured = $flag('featured', false);
        $active = $flag('active', true);
        if ($stockRaw !== '') {
            $stock = min(self::MAX_STOCK, (int) $stockRaw);
        } elseif (array_key_exists('inStock', $in)) {      // callers that only know the old on/off flag
            $stock = Text::boolish($in['inStock']) ? max(1, (int) ($existing['stock'] ?? 1)) : 0;
        } else {
            $stock = $existing ? (int) $existing['stock'] : 1;
        }
        $inStock = $stock > 0 ? 1 : 0;

        $sku = trim((string) ($in['sku'] ?? ($existing['sku'] ?? '')));
        $now = Text::now();
        $blob = Text::blob([
            $name, $brand, $category, I18n::categoryName($category, 'ru'), I18n::categoryName($category, 'en'), $description,
            $tr['ru']['name'] ?? '', $tr['en']['name'] ?? '', $sku,
        ]);

        return Db::tx(function () use ($existing, $name, $price, $old, $category, $brand, $description, $clean, $inStock, $stock, $featured, $active, $sizes, $blob, $sku, $tr, $now, $in): array {
            if ($existing) {
                $slug = $existing['slug'];
                $custom = trim((string) ($in['slug'] ?? ''));
                if ($custom !== '' && $custom !== $slug) {
                    $slug = self::uniqueSlug(Text::slugify($custom), $existing['id']);
                }
                Db::exec(
                    'UPDATE products SET name=?, slug=?, price=?, old_price=?, category=?, brand=?, description=?, images=?, in_stock=?, stock_qty=?, featured=?, active=?, sizes=?, search_blob=?, sku=?, translations=?, updated_at=? WHERE id=?',
                    [$name, $slug, $price, $old, $category, $brand !== '' ? $brand : null, $description, Text::jsonEncode($clean), $inStock, $stock, $featured, $active, Text::jsonEncode($sizes), $blob, $sku !== '' ? $sku : null, Text::jsonEncode((object) $tr), $now, $existing['id']]
                );
                $id = $existing['id'];
            } else {
                $id = Text::uid('p');
                $slug = self::uniqueSlug(Text::slugify($name), $id);
                Db::exec(
                    'INSERT INTO products (id,name,slug,price,old_price,category,brand,description,images,in_stock,stock_qty,featured,active,sizes,tags,search_blob,sku,views,sales,translations,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                    [$id, $name, $slug, $price, $old, $category, $brand !== '' ? $brand : null, $description, Text::jsonEncode($clean), $inStock, $stock, $featured, $active, Text::jsonEncode($sizes), '[]', $blob, $sku !== '' ? $sku : null, 0, 0, Text::jsonEncode((object) $tr), $now, $now]
                );
            }
            return ['ok' => true, 'product' => self::find($id)];
        });
    }

    public static function uniqueSlug(string $base, string $exceptId = ''): string
    {
        $slug = $base;
        $n = 2;
        while (true) {
            $hit = Db::val('SELECT id FROM products WHERE slug = ? LIMIT 1', [$slug]);
            if ($hit === null || (string) $hit === $exceptId) {
                return $slug;
            }
            $slug = $base . '-' . $n++;
        }
    }

    public static function setActive(string $id, bool $active): void
    {
        Db::exec('UPDATE products SET active = ?, updated_at = ? WHERE id = ?', [$active ? 1 : 0, Text::now(), $id]);
    }

    /** Set the exact number of pieces in stock (0 = out of stock). */
    public static function setStock(string $id, int $qty): void
    {
        $qty = max(0, min(self::MAX_STOCK, $qty));
        Db::exec('UPDATE products SET stock_qty = ?, in_stock = ?, updated_at = ? WHERE id = ?', [$qty, $qty > 0 ? 1 : 0, Text::now(), $id]);
    }

    /**
     * Atomically take $qty pieces for an order. Returns false (and changes nothing)
     * when fewer than $qty pieces are left.
     */
    public static function takeStock(string $id, int $qty): bool
    {
        return Db::exec(
            'UPDATE products SET stock_qty = stock_qty - ?, in_stock = CASE WHEN stock_qty - ? > 0 THEN 1 ELSE 0 END, updated_at = ?'
            . ' WHERE id = ? AND stock_qty >= ?',
            [$qty, $qty, Text::now(), $id, $qty]
        ) === 1;
    }

    /** Take pieces without failing (a cancelled order is re-opened); never goes below 0. */
    public static function removeStock(string $id, int $qty): void
    {
        $qty = max(0, $qty);
        Db::exec(
            'UPDATE products SET stock_qty = MAX(0, stock_qty - ?), in_stock = CASE WHEN stock_qty - ? > 0 THEN 1 ELSE 0 END, updated_at = ? WHERE id = ?',
            [$qty, $qty, Text::now(), $id]
        );
    }

    /** Put pieces back (cancelled order). Unknown products are ignored. */
    public static function returnStock(string $id, int $qty): void
    {
        Db::exec(
            'UPDATE products SET stock_qty = MIN(?, stock_qty + ?), in_stock = 1, updated_at = ? WHERE id = ?',
            [self::MAX_STOCK, max(0, $qty), Text::now(), $id]
        );
    }

    /** Move to trash (soft delete). */
    public static function delete(string $id): bool
    {
        $row = Db::one('SELECT * FROM products WHERE id = ?', [$id]);
        if (!$row) {
            return false;
        }
        Db::tx(function () use ($row, $id): void {
            Db::exec('INSERT OR REPLACE INTO trash (id, kind, data, deleted_at) VALUES (?,?,?,?)', ['p:' . $id, 'product', Text::jsonEncode($row), Text::now()]);
            Db::exec('DELETE FROM products WHERE id = ?', [$id]);
        });
        return true;
    }

    public static function restore(string $trashId): bool
    {
        $t = Db::one("SELECT * FROM trash WHERE id = ? AND kind = 'product'", [$trashId]);
        if (!$t) {
            return false;
        }
        $r = Text::jsonDecode($t['data'], []);
        if (!$r || !isset($r['id'])) {
            return false;
        }
        Db::tx(function () use ($r, $trashId): void {
            if (!Db::val('SELECT 1 FROM products WHERE id = ?', [$r['id']])) {
                $r['slug'] = self::uniqueSlug((string) $r['slug'], (string) $r['id']);
                $cols = array_keys($r);
                Db::exec(
                    'INSERT INTO products (' . implode(',', $cols) . ') VALUES (' . Db::in($cols) . ')',
                    array_values($r)
                );
                Categories::ensure((string) ($r['category'] ?? 'Інше'));
            }
            Db::exec('DELETE FROM trash WHERE id = ?', [$trashId]);
        });
        return true;
    }

    /** @return list<array{id:string,deletedAt:string,product:array}> */
    public static function trash(): array
    {
        $out = [];
        foreach (Db::all("SELECT * FROM trash WHERE kind = 'product' ORDER BY deleted_at DESC") as $t) {
            $r = Text::jsonDecode($t['data'], []);
            if ($r) {
                $out[] = ['id' => $t['id'], 'deletedAt' => $t['deleted_at'], 'product' => self::hydrate($r)];
            }
        }
        return $out;
    }

    public static function purge(string $trashId): void
    {
        Db::exec('DELETE FROM trash WHERE id = ?', [$trashId]);
    }

    public static function emptyTrash(): void
    {
        Db::exec("DELETE FROM trash WHERE kind = 'product'");
    }
}
